source 'https://rubygems.org'
ruby "1.9.3", :engine => "jruby", :engine_version => "1.7.19" 
gemspec