mkdir logstash-input-foo
cd logstash-input-foo
git init
git remote add example git@github .com:logstash-plugins/logstash-input-example.git
git clone https://github.com/logstash-plugins/logstash-input-example.git