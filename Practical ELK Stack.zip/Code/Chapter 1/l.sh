curl -L –O https://download.elastic.co/kibana/kibana/kibana-4.5.1.tar.gz
tar -zxvf kibana-4.5.1.tar.gz
cd kibana-4.5.1