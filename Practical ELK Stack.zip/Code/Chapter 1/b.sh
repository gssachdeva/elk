curl -L –O https://download.elastic.co/elasticsearch/elasticsearch/elasticsearch-2.3.3.tar.gz
tar -zxvf elasticsearch-2.3.3.tar.gz
cd elasticsearch-2.3.3