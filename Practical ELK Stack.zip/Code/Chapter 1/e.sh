bin/plugin install license
bin/plugin install marvel-agent