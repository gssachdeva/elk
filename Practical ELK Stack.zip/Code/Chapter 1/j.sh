bin/logstash -e 'input { stdin { } } output { elasticsearch { host = localhost } }' 
bin/logstash -e 'input { stdin { } } output { elasticsearch {hosts => ["localhost:9200"]} }'