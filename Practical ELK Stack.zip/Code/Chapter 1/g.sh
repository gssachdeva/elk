curl -L https://download.elastic.co/logstash/logstash/logstash-2.3.3.tar.gz
tar -zxvf logstash-2.3.3.tar.gz
cd logstash-2.3.3