curl -XPUT 'localhost:9200/phones/_alias/ph-alias'
curl -XDELETE 'localhost:9200/old-phones/_alias/old-ph-alias'
