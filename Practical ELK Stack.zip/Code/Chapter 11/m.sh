curl -XPOST 'http://localhost:9200/_aliases' -d '
{
  "actions" : [
  {
    "add" : {
      "index" : "phones",
      "alias" : "ph-alias"
    }
  },
  {
    "remove" : {
      "index" : "old-phones",
      "alias" : "old-ph-alias"
    }
  },
  ]
}' 