curl -XPOST 'localhost:9200/_aliases' -d '              
{
  "actions" : [
  {
    "add" : {
      "index" : "phones",
      "alias" : "Lenovo-group",
      "filter" : {
        "term" : {"make" : "Lenovo"} 
      },
      "routing" : "Lenovo"
    }
  }
 ]
}' 