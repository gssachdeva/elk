curl -XPOST 'localhost:9200/routed-phones' -d ' 
{
  "mappings" : { 
    "sales" : {
      "_routing" : {
        "required" : "true"
      },
      "properties" : {
        "color" : {
          "type" : "string"
        },
        "make" : {
          "type" : "string"
        },
        "price" : {
          "type" : "long"
        },
        "sold" : {
          "type" : "date",
          "format" : "strict_date_optional_time||epoch_millis"
        }
      }
    }
  }
 }
}'