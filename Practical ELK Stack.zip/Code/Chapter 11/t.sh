curl -XGET 'localhost:9200/htc-group/_count' -d '
{
  "query" : {
    "match_all" : {} 
  }
}'