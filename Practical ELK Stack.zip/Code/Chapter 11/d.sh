curl -XPUT "localhost:9200/_cluster/settings" -d  '{
    "transient" : {
        "cluster.routing.allocation.exclude_ip" : "192.168.1.5"
    }
}'