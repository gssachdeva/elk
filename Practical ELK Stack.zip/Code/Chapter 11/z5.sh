curl -XPOST 'localhost:9200/Lenovo-group/_search?pretty' -d '
{
  "query" : {
    "match_all" : {}
  },
  "fields" : ["make"]
}' 