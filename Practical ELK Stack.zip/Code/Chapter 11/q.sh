curl -XGET 'http://localhost:9200/foo/_alias/bar'
curl -XGET 'http://localhost:9200/foo/_alias/*'
curl -XGET 'http://localhost:9200/_alias/bar'
curl -XGET 'http://localhost:9200/_alias/bar*' 
