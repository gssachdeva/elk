mkdir elasticsearch2
cd elasticsearch2
tar -zxvf elasticsearch-2.3.3.tar.gz
cd elasticsearch-2.3.3
bin/elasticsearch