curl -XPOST 'localhost:9200/phones/sales/11?routing=Sony' -d '
{
  "make" : "Sony",
  "color" : "black",
  "price" : 150,
  "sold" : "2016-12-15"
}'
