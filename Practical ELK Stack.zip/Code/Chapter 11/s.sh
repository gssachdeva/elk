curl -XGET 'localhost:9200/phones/sales/_count' -d '
{
  "query" : {
    "match_all" : {} 
  }
}'