curl -XPUT 'http://localhost:9200/foo/_alias/bar'
curl -XPUT 'http://localhost:9200/_all/_alias/bar'
curl -XPUT 'http://localhost:9200/foo1,foo2/_alias/bar'
curl -XPUT 'http://localhost:9200/foo*/_alias/bar'