curl -XPOST 'localhost:9200/routed-phones/sales/13' -d ' 
{
  "make" : "Blackberry",
  "color" : "black",
  "price" : 140,
  "sold" : "2016-11-29"
}'