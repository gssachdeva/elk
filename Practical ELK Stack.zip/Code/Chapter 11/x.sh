curl -XPOST 'localhost:9200/phones/sales/_search?routing=Lenovo,Blackberry' -d '
{
  "query" : {
    "match" : {
      "color" : "black"
    }
  }
}' 