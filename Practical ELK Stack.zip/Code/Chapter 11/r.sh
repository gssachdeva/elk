curl -XPOST 'http://localhost:9200/_aliases' -d '
{
  "actions" : [
  {
    "add" : {
      "index" : "phones",
      "alias" : "htc-group",
      "filter" : {
        "term" : {"make" : "htc"}
      }
    }
  }
  ]
}'