curl -XPOST 'localhost:9200/phones/sales/10?routing=Lenovo' -d '
{
  "make" : "Lenovo",
  "color" : "gold",
  "price" : 100,
  "sold" : "2016-11-03"
}'