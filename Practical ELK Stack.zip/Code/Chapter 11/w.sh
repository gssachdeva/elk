curl -XPOST 'localhost:9200/phones/sales/12?routing=Blackberry' -d '
{
  "make" : "Blackberry",
  "color" : "black",
  "price" : 120,
  "sold" : "2016-11-21"
}'