curl 'localhost:9200/phones/_alias?pretty'
{
    "phones" : {
        "aliases" : {
            "ph-alias" : { }
        }
    }
} 