curl -XPUT 'localhost:9200/sm/_mapping/play' -d '
{
  "properties": {
    "label" : {
      "type": "string",
      "index": "not_analyzed"
    }
  }
}' 