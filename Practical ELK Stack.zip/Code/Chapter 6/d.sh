curl -XPUT 'localhost:9200/sm' -d '
{
  "mappings": {
    "play": {
      "properties": {
        "play": {
          "type": "string",
          "analyzer": "english"
        },                   
        "author": {
          "type": "string",
          "analyzer": "english"
        },                   
        "published": {
          "type": "string",
          "analyzer": "english"
        }                    
      }
    }
  }
}'  