curl -XGET "http://localhost:9200/_mget" -d '{
    "docs" : [
        {
            "_index" : "foo", 
            "type" : "eis",
            "_id" : "33124"
        },
        {
            "_index" : "foo", 
            "type": "eis", 
            "_id" : "AVbA4WNg7uqRWQFJiJSn",
            "_source" : "department"
        }
    ] 
}'