curl -XPOST "http://localhost:9200/foo/eis" -d '
{
    "name": "Eric Anderson",
    "id": 45796,
    "manager": " Marcus Benson",
    "department": "hr",
    "contact details": {
        "mobile phone": "+12074235478",
        "email": "eric.anderson@foo.com" 
    }
}
' 