curl -XPUT "http://localhost:9200/foo/eis/33124" -d '
{
    "name": "Tom Smith",
    "id": 33124,
    "manager": "Rob Stewart",
    "department": "sales",
    "contact details": {
        "mobile phone": "+12072553130",
        "email": "tom.smith@foo.com" 
    }
}
'