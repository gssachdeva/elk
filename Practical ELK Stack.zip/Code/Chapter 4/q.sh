curl -XPOST "http://localhost:9200/foo/eis/33124" -d '
{
    "doc": {
        "role": "Analyst"
    }
}
' 