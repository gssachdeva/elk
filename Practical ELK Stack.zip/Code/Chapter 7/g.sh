curl -XGET 'localhost:9200/phones/sales/_search?search_type=count&pretty' -d '
{
  "aggs" : {
    "sales" : {
      "date_histogram" : {
        "field" : "sold",
        "interval" : "month",
        "format" : "yyyy-MM-dd"
      }
    }
  }
}' 