curl -XGET 'localhost:9200/phones/sales/_search?search_type=count&pretty' -d '
{
  "aggs" : {
    "colors" : {
      "terms" : {
        "field" : "color",
        "order" : {
          "stats.variance" : "asc"
        }
      },
      "aggs" : {
        "stats" : {
          "extended_stats" : {"field" : "price"}
        }
      }
    }
  }
}' 