curl -XGET 'localhost:9200/phones/sales/_search?search_type=count&pretty' -d '
{
  "aggs" : {
    "colors" : {
      "terms" : {
        "field" : "color",
        "order" : {
          "_count" : "asc"
        }
      }
    }
  }
}' 