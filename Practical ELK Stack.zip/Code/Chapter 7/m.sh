curl -XGET 'localhost:9200/phones/sales/_search?search_type=count&pretty' -d '
{
  "query" : {
    "filtered" : {
      "filter" : { 
        "range" : {
          "price" : {
            "gte" : 100
          }
        }
      }
    }
  },
  "aggs" : {
    "single_mean_price" : {
      "avg" : { "field" : "price" } 
    }
  }
}' 