curl -XGET 'localhost:9200/phones/sales/_search?search_type=count&pretty' -d '
{
  "aggs" : {
    "makes" : {
      "terms" : {
        "field" : "make",
        "size" : 10
      },
      "aggs" : {
        "stats" : { 
          "extended_stats" : {
            "field" : "price"
          }
        }
      }
    }
  }
} '