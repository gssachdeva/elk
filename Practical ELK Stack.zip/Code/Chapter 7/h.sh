curl -XGET 'localhost:9200/phones/sales/_search?search_type=count&pretty' -d '
{
  "aggs" : {
    "sales" : {
      "date_histogram" : {
        "field" : "sold",
        "interval" : "quarter",
        "format": "yyyy-MM-dd",
        "min_doc_count" : 0,
        "extended_bounds" : {
          "min" : "2016-01-01",
          "max" : "2016-12-31"
        }
      },
      "aggs" : {
        "per_make_total" : {
          "terms" : {
            "field" : "make"
          },
          "aggs" : {
            "total_price" : {
              "sum" : {"field" : "price" }
            }
          }
        },
        "grand_total": {
          "sum": { "field": "price" }
        },
      },
    },
  },
}' 