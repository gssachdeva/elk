curl -XGET 'localhost:9200/phones/sales/_search?search_type=count&pretty' -d '
{
  "query" : {
    "match_all" : {}
  },
  "aggs" : {
    "colors" : {
      "terms" : {
        "field" : "color"
      }
    }
  }
}' 