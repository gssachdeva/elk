curl -XGET 'localhost:9200/phones/sales/_search?pretty' -d '
{
  "query" : {
    "match" : {
      "make" : "iphone"
    }
  },
  "aggs" : {
    "single_mean_price" : {
      "avg" : { "field" : "price" }
      },
    "all" : {
      "global" : {},
      "aggs" : {
        "mean_price" : {
          "avg" : { "field" : "price" }
        }
      }       
    }
  }
}' 