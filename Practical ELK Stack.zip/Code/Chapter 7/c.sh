curl -XGET 'localhost:9200/phones/sales/_search?search_type=count&pretty' -d '
{
  "aggs" : {
    "colors" : {
      "terms" : {
        "field" : "color"
      },
      "aggs" : { 
        "mean_price" : {
          "avg" : {
            "field" : "price"
          }
        },
        "make" : {
          "terms" : {
            "field" : "make"
          }
        }
      }
    }
  }
}'  