curl -XGET 'localhost:9200/phones/sales/_search?search_type=count&pretty' -d '
{
  "query" : {
    "match" : {
      "make" : "LG"
    }
  },
  "aggs" : {
    "recent_sales" : { 
      "filter" : {
        "range" : {
          "sold" : {
            "from" : "now-1M"
          }
        }
      },
      "aggs" : {
        "mean_price" : {
          "avg" : {
            "field" : "price"
          }
        }
      }
    }
  }
}' 