curl -XGET 'localhost:9200/phones/sales/_search?search_type=count&pretty' -d '
{
  "query" : {
    "match" : {
      "make" : "iphone"
    }
  },
  "post_filter" : {
    "term" : {
      "color" : "silver"
    }
  },
  "aggs" : {
    "all_colors" : {
      "terms" : { "field" : "color" }
    }
  }
}' 