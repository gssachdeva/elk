curl -XGET 'localhost:9200/phones/sales/_search?pretty' -d '
{
  "query" : {
    "match" : {
      "make" : "iphone"
    }
  },
  "aggs" : {
    "colors" : {
      "terms" : {
        "field" : "color"
      }
    }
  }
}' 