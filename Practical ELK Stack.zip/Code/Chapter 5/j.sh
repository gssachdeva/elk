curl -XGET 'localhost:9200/_search?pretty' 
{
    "query": {
        "filtered": {
             "filter": { "actor": "Vin Diesel" }}
        }
    }
}  
