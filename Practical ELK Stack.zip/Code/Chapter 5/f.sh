curl -XGET 'localhost:9200/_search?pretty’ –d ‘
{
    "query": {
        "match_all": {}
    }
}’