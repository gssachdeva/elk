curl –XGET ‘localhost:9200/_search?size=3&pretty’ 
curl –XGET ‘localhost:9200/_search?size=3&from=3&pretty’ 
curl –XGET ‘localhost:9200/_search?size=3&from=6&pretty’ 
curl –XGET ‘localhost:9200/_search?size=3&from=9&pretty’ 
curl –XGET ‘localhost:9200/_search?size=3&from=12&pretty’ 