curl -XGET 'localhost:9200/ws/play/_validate/query?explain&pretty'
{
    "query": {
        "play" : {
            "match" : "Pride and Prejudice"
        }
    }
} 