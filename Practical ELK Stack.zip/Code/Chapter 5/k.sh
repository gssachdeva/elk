curl -XGET 'localhost:9200/_search?pretty' 
{
    "query": {
        "filtered": {
            "query": { "match_all": {}},
            "filter": { "actor": "Vin Diesel" }}
        }
    }
} 