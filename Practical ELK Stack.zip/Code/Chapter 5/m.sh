curl -XGET 'localhost:9200/ws/play/_validate/query?pretty'
{
    "query": {
        "play" : {
            "match" : "Pride and Prejudice"
        }
    }
} 