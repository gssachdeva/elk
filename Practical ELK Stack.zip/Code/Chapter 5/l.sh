curl -XGET 'localhost:9200/_search?pretty'
{
  "query": {
    "filtered": {
      "filter": {
        "bool": {
          "must": { "term": { "movie": "Hollywood" }},
          "must_not": {
            "query": {
              "match": { "actor": "Vin Diesel" }
            }
          }
        }
      }
    }
  }
} 