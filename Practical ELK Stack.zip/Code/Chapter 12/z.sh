curl -XPUT 'localhost/9200/_snapshot/foo_backup/snapshot_2' -d '
{
  "indices" : "index_1,index_2"
}