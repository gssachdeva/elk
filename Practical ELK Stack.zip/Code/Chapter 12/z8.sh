curl -XPOST 'localhost:9200/_snapshot/foo_backup/snapshot_2/_restore' -d '
{
  "indices" : "index_1",
  "rename_pattern" : ."index_(.+)",
  "rename_replacement" : "restored_index_$1"
}'
