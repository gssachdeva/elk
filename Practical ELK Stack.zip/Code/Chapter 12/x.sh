curl -XPOST 'localhost:9200/_snapshot/foo_backup' -d '
{
  "type" : "fs"
  "settings" : {
    "location" : "/mount/backups/foo_backup",
    "max_snapshot_bytes_per_sec" : "30mb",
    "max_restore_bytes_per_sec" : "30mb"
  }
}'
