curl -XGET "http://localhost:9200/foo/_mget" -d '{
    "docs" : [
        {
            "type" : "eis",	
            "_id" : "33124"
        },
        {
            "type": "eis", 
            "_id" : "AVbA4WNg7uqRWQFJiJSn",
            "_source" : "department"
        }
    ]
}' 