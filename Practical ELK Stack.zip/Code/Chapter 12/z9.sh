curl -XGET 'localhost:9200/_recovery/restored_index_2'
curl -XGET 'localhost:9200/_recovery'