curl -XPUT 'localhost:9200/_cluster/settings' -d '
{
  "transient" : {
    "logger.discovery" : "DEBUG"
  }
}' 