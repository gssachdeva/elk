curl -XPUT 'localhost:9200/_template/logging_index' -d '
{
  "template" : "logstash-*",
  "settings" : {
    "number_of_shards" : 2,
    "number_of_replicas" : 1
  },
  "mappings" : {
    "logs" : {
      "properties" : {
        "@timestamp" : {
          "type" : "date",
          "format" : "strict_date_optional_time||epoch_millis"
        },
        "@version" : {
          "type" : "string",
          "index" : "not_analyzed"
        },
        "date_of_record" : {
          "type" : "date",
          "format" : "strict_date_optional_time||epoch_millis"
        },
        "day_of_year" : {
          "type" : "string",
          "norms" : {
            "enabled" : false
          },
          "fielddata" : {
            "format" : "disabled"
          },
          "fields" : {
            "raw" : {
              "type" : "string",
              "index" : "not_analyzed",
              "ignore_above" : 256
            }
          }
        }
      }
    }
  },
  "aliases" : { "december" : {} }
}' 
