curl -XPUT 'localhost:9200/_cluster/settings' -d '
{
  "persistent" : {
    "indices.store.throttle" : {
      "type" : "all",
      "max_bytes_per_sec" : "250mb"
    }
  }
}' 