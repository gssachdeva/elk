curl -XGET 'localhost:9200/_template' 
curl -XGET 'localhost:9200/_template/log_index'
curl -XGET 'localhost:9200/_template/log_index_1,log_index_2' 
curl -XGET 'localhost:9200/_template/log_*' 
