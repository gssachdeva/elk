curl -XGET "http://localhost:9200/foo/eis/_mget" -d '{
    "ids" : [ "33124", "AVbA4WNg7uqRWQFJiJSn" ]
}' 