curl -XPUT 'localhost:9200/_template/logging_index_all' -d '
{
  "template" : "logstash-12-*",
  "order" : 1,
  "settings" : {
    "number_of_shards" : 2,
    "number_of_replicas" : 1
  },
  "mappings" : {
    "date" : { "store" : false }
  },
  "alias" : { "december" : {} }
}' 

curl -XPUT 'localhost:9200/_template/logging_index' -d '
{
  "template" : "logstash-*",
  "order" : 0,
  "settings" : {
    "number_of_shards" : 2,
    "number_of_replicas" : 1
  },
  "mappings" : {
    "date" : { "store" : true }
  }
}' 