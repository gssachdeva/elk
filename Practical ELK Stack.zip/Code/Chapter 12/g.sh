curl -XPUT 'localhost:9200/phones/sales/_warmer/_search?search_type=count&pretty' -d '
{
  "aggs" : {
    "colors" : {
      "terms" : {
        "field" : "color",
        "order" : {
          "_count" : "asc"
        }
      }
    }
  }
}' 