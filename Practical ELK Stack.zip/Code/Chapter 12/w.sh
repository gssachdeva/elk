curl -XPUT 'localhost:9200/foo_backup'
{  
  "type" : "fs",
  "settings" : {
    "location" : "/mount/backups/foo_backup"
  }
}