curl -XPUT 'localhost:9200/{index}/_settings' -d '
{
  "index.cache.filter.expire" : "30m"
}' 