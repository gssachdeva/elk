curl -XGET 'localhost:9200/phones/sales/_warmer/?pretty' 
curl -XDELETE 'localhost:9200/phones/sales/_warmer/?pretty' 
